package org.androidtown.shaketest;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

public class MainUIActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main_ui);


    }
}
